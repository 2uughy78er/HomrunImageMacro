package com.example.homerunmacro;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    static final int REQ_CAPTURE=101;
    TextView status;
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32,32,32,32);
        TextView title=new TextView(this); title.setText("홈런레이스 이미지 매크로"); title.setTextSize(24); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,80));
        status=new TextView(this); status.setText("1) 접근성 서비스 활성화 → 2) 화면 캡처 허용 → 3) 시작"); status.setTextSize(16); status.setPadding(0,20,0,20); status.setMovementMethod(new ScrollingMovementMethod()); root.addView(status,new LinearLayout.LayoutParams(-1,0,1));
        Button acc=new Button(this); acc.setText("접근성 서비스 설정"); acc.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); root.addView(acc);
        Button capture=new Button(this); capture.setText("화면 캡처 권한 허용"); capture.setOnClickListener(v->{MediaProjectionManager m=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE); startActivityForResult(m.createScreenCaptureIntent(),REQ_CAPTURE);}); root.addView(capture);
        Button start=new Button(this); start.setText("매크로 시작"); start.setOnClickListener(v->startMacro()); root.addView(start);
        Button stop=new Button(this); stop.setText("매크로 정지"); stop.setOnClickListener(v->stopService(new Intent(this,ScreenMacroService.class))); root.addView(stop);
        setContentView(root);
    }
    void startMacro(){ status.setText("실행 중: 0.5초마다 이미지 탐색\nPLAY → REPLAY 순서로 반복합니다."); startService(new Intent(this,ScreenMacroService.class).putExtra("start",true)); }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r==REQ_CAPTURE && c==RESULT_OK){ ScreenMacroService.projectionResultCode=c; ScreenMacroService.projectionData=d; status.setText("화면 캡처 권한 완료. 접근성 서비스가 켜져 있다면 매크로 시작을 누르세요."); }}
}
