package com.example.homerunmacro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;

public class MacroAccessibilityService extends AccessibilityService {
    private static MacroAccessibilityService instance;
    @Override public void onServiceConnected(){ instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){}
    public static boolean tap(float x,float y){
        if(instance==null || Build.VERSION.SDK_INT<24) return false;
        Path p=new Path(); p.moveTo(x,y);
        GestureDescription.StrokeDescription s=new GestureDescription.StrokeDescription(p,0,80);
        return instance.dispatchGesture(new GestureDescription.Builder().addStroke(s).build(),null,null);
    }
}
